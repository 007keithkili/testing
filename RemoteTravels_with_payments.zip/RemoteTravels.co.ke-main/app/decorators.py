from functools import wraps

from flask import abort, current_app
from flask_login import current_user

from .models import Permission


def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.can(permission):
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def admin_required(f):
    return permission_required(Permission.ADMIN)(f)


def editor_required(f):
    """Allow administrators and editors to manage the catalogue."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.can(Permission.ADMIN) and not current_user.can(Permission.EDIT_CONTENT):
            abort(403)
        return f(*args, **kwargs)
    return decorated_function
