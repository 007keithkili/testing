from flask import Blueprint

auth = Blueprint('auth', __name__)

from . import forms, views  # noqa: E402,F401
